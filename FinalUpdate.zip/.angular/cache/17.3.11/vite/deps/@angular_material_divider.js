import {
  MatDivider,
  MatDividerModule
} from "./chunk-LORKOIIT.js";
import "./chunk-V4U43JPX.js";
import "./chunk-4OT7MVQX.js";
import "./chunk-6SVQX5TP.js";
import "./chunk-FQEM7BSC.js";
import "./chunk-SF7Q7RME.js";
import "./chunk-SDQMWN4J.js";
import "./chunk-6UHCRHZ7.js";
import "./chunk-DSK7TZNG.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
